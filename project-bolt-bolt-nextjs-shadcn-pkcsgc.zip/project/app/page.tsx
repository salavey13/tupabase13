"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useApp } from '@/lib/contexts/app-context';

export default function HomePage() {
  const router = useRouter();
  const { state } = useApp();

  useEffect(() => {
    // Redirect based on authentication status
    if (state.user) {
      router.push('/events');
    } else {
      router.push('/login');
    }
  }, [state.user, router]);

  return null; // No UI needed as we're redirecting
}