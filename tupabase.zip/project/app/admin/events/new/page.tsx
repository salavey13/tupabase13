"use client";

import { EventForm } from "@/components/EventForm";

export default function CreateEventPage() {
  return <EventForm />;
}